<?php
    // See all errors and warnings
    error_reporting(E_ALL);

    // replace with your position_surname
?>